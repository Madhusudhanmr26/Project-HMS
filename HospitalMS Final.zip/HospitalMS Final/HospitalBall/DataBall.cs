﻿using DataLib;
using HospitalDal;
using System;
using System.Collections.Generic;
using static HospitalDal.DataComponent;

namespace HospitalBall
{
    public interface IHospitalComponent
    {
        void AddInPatient(InPatient patient);
        void UpdateInPatient(InPatient patient);
        List<InPatient> GetAllInPatients();
        InPatient GetInPatient(int InPatientID);
        void AddOutPatient(OutPatient patient);
        void UpdateOutPatient(OutPatient patient);
        List<OutPatient>GetAllOutPatient();
        OutPatient GetOutPatient(int OutPatientID);
        void DeleteOutPatient(int OutPatientID);
        void AddStaff(Staff staff);
        void UpdateStaff(Staff staff);
        void DeleteStaff(int ID);
        List<Staff> GetAllStaff();
        bool AdminLogin(string name);
        void Register(string name, string password);
        void AddBill(Bill bill);
        void UpdateBill(Bill bill);
        List<Bill> GetAllBill();
        Bill GetPatient(int InPatientID);
    }
    public class HospitalComponent : IHospitalComponent
    {
        static IDataComponent pat = DataFactory.CreateComponent();
        public void AddBill(Bill bill)
        {
            try
            {
                pat.AddBill(bill);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void AddInPatient(InPatient patient)
        {
            try
            {
                pat.AddInPatient(patient);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void AddOutPatient(OutPatient patient)
        {
            try
            {
                pat.AddOutPatient(patient);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void AddStaff(Staff staff)
        {
            try
            {
                pat.AddStaff(staff);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void DeleteOutPatient(int OutPatientID)
        {
            try
            {
                pat.DeleteOutPatient(OutPatientID);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void DeleteStaff(int ID)
        {
            try
            {
                pat.DeleteStaff(ID);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public List<Bill> GetAllBill()
        {
            try
            {
                return pat.GetAllBill();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public List<InPatient> GetAllInPatients()
        {
            try
            {
                return pat.GetAllInPatients();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public List<OutPatient> GetAllOutPatient()
        {
            try
            {
                return pat.GetAllOutPatient();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
         public List<Staff> GetAllStaff()
        {
            try
            {
                return pat.GetAllStaff();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public InPatient GetInPatient(int InPatientID)
        {
            try
            {
                return pat.GetInPatient(InPatientID);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public OutPatient GetOutPatient(int OutPatientID)
        {
            try
            {
                return pat.GetOutPatient(OutPatientID);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public Bill GetPatient(int InPatientID)
        {
            try
            {
                return pat.GetBill(InPatientID);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void Register(string name, string password)
        {
            throw new NotImplementedException();
        }
        public void UpdateBill(Bill bill)
        {
            try
            {
                pat.UpdateBill(bill);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void UpdateInPatient(InPatient patient)
        {
            try
            {
                pat.UpdateInPatient(patient);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void UpdateOutPatient(OutPatient patient)
        {
            try
            {
                pat.UpdateOutPatient(patient);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public bool AdminLogin(string name)
        {
            throw new NotImplementedException();
        }
        public void UpdateStaff(Staff staff)
        {
            try
            {
                pat.UpdateStaff(staff);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
