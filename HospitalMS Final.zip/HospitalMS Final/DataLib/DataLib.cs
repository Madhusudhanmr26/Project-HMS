﻿using System;
using System.Collections.Generic;
using System.Linq;
using DataLib;

namespace HospitalDal
{
    public interface IDataComponent
    {
        void AddInPatient(InPatient patient);
        void UpdateInPatient(InPatient patient);
        List<InPatient> GetAllInPatients();
        InPatient GetInPatient(int InPatientID);
        void AddOutPatient(OutPatient patient);
        void UpdateOutPatient(OutPatient patient);
        List<OutPatient> GetAllOutPatient();
        OutPatient GetOutPatient(int OutPatientID);
        void DeleteOutPatient(int OutPatientID);
        void AddStaff(Staff staff);
        void UpdateStaff(Staff staff);
        void DeleteStaff(int ID);
        List<Staff> GetAllStaff();
        bool AdminLogin(string name);
        void Register(string name,string password);
        void AddBill(Bill bill);
        void UpdateBill(Bill bill);
        List<Bill> GetAllBill();
        Bill GetBill(int InPatientID);
    }

    public class DataComponent : IDataComponent
    {
       public static HospitalAppEntities1 hos = new HospitalAppEntities1();
        public void AddBill(Bill bill)
        {
            try
            {
                hos.Bills.Add(bill);
                hos.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void AddInPatient(InPatient patient)
        {

            try
            {
                hos.InPatients.Add(patient);
                hos.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void AddOutPatient(OutPatient patient)
        {
            try
            {
                hos.OutPatients.Add(patient);
                hos.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void AddStaff(Staff staff)
        {
            try
            {
                hos.Staffs.Add(staff);
                hos.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void DeleteOutPatient(int OutPatientID)
        {
            try
            {
                var selected = hos.OutPatients.FirstOrDefault((a) => a.OutPatientID == OutPatientID);
                if (selected == null) throw new Exception("OutPatient not found to delete");
                hos.OutPatients.Remove(selected);
                hos.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void DeleteStaff(int ID)
        {
            try
            {
                var selected = hos.Staffs.FirstOrDefault((a) => a.ID == ID);
                if (selected == null) throw new Exception("Staff not found to delete");
                hos.Staffs.Remove(selected);
                hos.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Bill> GetAllBill()
        {
            try
            {
                return new HospitalAppEntities1().Bills.ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<InPatient> GetAllInPatients()
        {
            try
            {
                return new HospitalAppEntities1().InPatients.ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public List<OutPatient> GetAllOutPatient()
        {
            try
            {
                return new HospitalAppEntities1().OutPatients.ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public List<Staff> GetAllStaff()
        {
            try
            {
                return new HospitalAppEntities1().Staffs.ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public Bill GetBill(int InPatientID)
        {
            var Inbill = hos.Bills.FirstOrDefault((p) => p.InPatientID == InPatientID);
            if (Inbill != null)
            {
                return Inbill;
            }
            throw new Exception();
        }

        public InPatient GetInPatient(int InPatientID)
        {
            var Inpat = hos.InPatients.FirstOrDefault((p) => p.InPatientID == InPatientID);
            if (Inpat != null)
            {
                return Inpat;
            }
            throw new Exception();
        }

        public OutPatient GetOutPatient(int OutPatientID)
        {
            var Inpat = hos.OutPatients.FirstOrDefault((p) => p.OutPatientID == OutPatientID);
            if (Inpat != null)
            {
                return Inpat;
            }
            throw new Exception();
        }
        public void Register(string name, string password)
        {
            throw new NotImplementedException();
        }
        public void UpdateBill(Bill bill)
        {
            try
            {
                var selected = hos.Bills.FirstOrDefault((e) => e.InPatientID == bill.InPatientID);
                if (selected == null) throw new Exception("Patient not found to update");
                hos.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void UpdateInPatient(InPatient patient)
        {
            try
            {
                var selected = hos.InPatients.FirstOrDefault((e) => e.InPatientID == patient.InPatientID);
                if (selected == null) throw new Exception("Patient not found to update");
                hos.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void UpdateOutPatient(OutPatient patient)
        {
            try
            {
                var selected = hos.OutPatients.FirstOrDefault((e) => e.OutPatientID == patient.OutPatientID);
                if (selected == null) throw new Exception("Patient not found to update");
                hos.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void UpdateStaff(Staff staff)
        {
            try
            {
                var selected = hos.Staffs.FirstOrDefault((e) => e.ID == staff.ID);
                if (selected == null) throw new Exception("Staff not found to update");
                hos.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        bool IDataComponent.AdminLogin(string name)
        {
            throw new NotImplementedException();
        }
        public static class DataFactory
        {
            public static IDataComponent CreateComponent()
            {
                return new DataComponent();
            }
        }
    }
}
    

