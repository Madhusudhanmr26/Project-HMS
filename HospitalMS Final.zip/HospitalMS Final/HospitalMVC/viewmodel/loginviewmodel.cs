﻿using HospitalMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HospitalMVC.viewmodel
{
    public class loginviewmodel
    {
        public login log
        {
            get;
            set;
        }

    }
}