﻿using HospitalMVC.viewmodel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HospitalMVC.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(loginviewmodel avm)
        {
            if(avm.log.username.Equals("abc") && avm.log.password.Equals("123"))
            {
                Session["username"] = avm.log.username;
                return View("welcome");
            }
            else
            {
                ViewBag.Error = "login isInvalid";
                return View("Index");
            }
        }
        public ActionResult logout()
        {
            Session.Remove("username");
            return RedirectToAction("Index");
        }
        
    }
}