﻿using SampleWinApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web.Mvc;

namespace HospitalMVC.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult About()
        {
            return View();
        }
        public ActionResult InPatient()
        {
            return View();
        }
        [HttpPost]

        //HTTP POST InPatient
        public ActionResult InPatient(InPatientHos inPatientHos)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/InPatient");
                var postTask = client.PostAsJsonAsync("InPatient", inPatientHos);
                postTask.Wait();
                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("InPatient");
                }
            }
            ModelState.AddModelError(string.Empty, "Server Error.");

            return View(inPatientHos);
        }
        // GET Show InPatient
        public ActionResult ShowIn()
        {
            IEnumerable<InPatientHos> inPatient = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/");
                
                var responseTask = client.GetAsync("InPatient");
                responseTask.Wait();
                
                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<InPatientHos>>();
                    readTask.Wait();

                    inPatient = readTask.Result;
                }
                else 
                {
                    inPatient = Enumerable.Empty<InPatientHos>();

                    ModelState.AddModelError(string.Empty, "Server error.");
                }
            }
            return View(inPatient);
        }
        //Edit the inpatient
        public ActionResult EditIn(int id)
        {
            InPatientHos inpat = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/");
                //HTTP GET
                var responseTask = client.GetAsync("InPatient?id=" + id.ToString());
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<InPatientHos>();
                    readTask.Wait();

                    inpat = readTask.Result;
                }
            }
            return View(inpat);
        }

        [HttpPost]
        public ActionResult EditIn(InPatientHos inPatient)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/InPatient");

                //HTTP POST
                var putTask = client.PutAsJsonAsync("InPatient", inPatient);
                putTask.Wait();

                var result = putTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    return RedirectToAction("ShowIn");
                }
            }
            return View(inPatient);
        }
        public ActionResult OutPatient()
        {
            return View();
        }
        [HttpPost]//Post OutPatient

        //HTTP POST
        public ActionResult OutPatient(OutPatientHos outPatientHos)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/OutPatient");
                var postTask = client.PostAsJsonAsync("OutPatient", outPatientHos);
                postTask.Wait();
                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("OutPatient");
                }
            }
        
            ModelState.AddModelError(string.Empty, "Server Error.");

            return View(outPatientHos);
        }
        
        // GET show all outpatient
        public ActionResult ShowOut()
        {
            IEnumerable<OutPatientHos> outPatient = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/");
                //HTTP GET
                var responseTask = client.GetAsync("Outpatient");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<OutPatientHos>>();
                    readTask.Wait();

                    outPatient = readTask.Result;
                }
                else 
                {
                    outPatient = Enumerable.Empty<OutPatientHos>();

                    ModelState.AddModelError(string.Empty, "Server error.");
                }
            }
            return View(outPatient);
        }
        //Edit the outpatient
        public ActionResult EditOut(int id)
        {
            OutPatientHos outpat = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/");
                //HTTP GET
                var responseTask = client.GetAsync("OutPatient?id=" + id.ToString());
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<OutPatientHos>();
                    readTask.Wait();

                    outpat = readTask.Result;
                }
            }
            return View(outpat);
        }

        [HttpPost]
        public ActionResult EditOut(OutPatientHos outPatient)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/OutPatient");

                //HTTP POST
                var putTask = client.PutAsJsonAsync<OutPatientHos>("OutPatient", outPatient);
                putTask.Wait();

                var result = putTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("ShowOut");
                }
            }
            return View(outPatient);
        }
        public ActionResult DelOut()
        {
            IList<OutPatientHos> dout = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/");
                //HTTP GET
                var responseTask = client.GetAsync("OutPatient");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<OutPatientHos>>();
                    readTask.Wait();

                    dout = readTask.Result;
                }
            }
            return View(dout);
        }
        public ActionResult DelOut(int id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/");

                //HTTP DELETE
                var deleteTask = client.DeleteAsync("OutPatient/" + id.ToString());
                deleteTask.Wait();

                var result = deleteTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    return RedirectToAction("ShowOut");
                }
            }
            return RedirectToAction("Index");
        }
        public ActionResult Bill()
        {
            return View();
        }
        [HttpPost]// Post Bill

        //HTTP POST
        public ActionResult Bill(BillHos billHos)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/");
                var postTask = client.PostAsJsonAsync("Bill", billHos);
                postTask.Wait();
                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Bill");
                }
            }
            ModelState.AddModelError(string.Empty, "Server Error.");

            return View(billHos);
        }

        // GET show all Bills
        public ActionResult ShowBill()
        {
            IEnumerable<BillHos> bill = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/");
                //HTTP GET
                var responseTask = client.GetAsync("Bill");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<BillHos>>();
                    readTask.Wait();

                    bill = readTask.Result;
                }
                else 
                {
                    bill = Enumerable.Empty<BillHos>();

                    ModelState.AddModelError(string.Empty, "Server error. ");
                }
            }
            return View(bill);
        }
        //Edit the bill
        public ActionResult EditBill(int id)
        {
            BillHos bill = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/");
                //HTTP GET
                var responseTask = client.GetAsync("Bill?id=" + id.ToString());
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<BillHos>();
                    readTask.Wait();

                    bill = readTask.Result;
                }
            }
            return View(bill);
        }

        [HttpPost]
        public ActionResult EditBill(BillHos bills)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/");

                //HTTP POST
                var putTask = client.PutAsJsonAsync<BillHos>("Bill", bills);
                putTask.Wait();

                var result = putTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    return RedirectToAction("ShowBill");
                }
            }
            return View(bills);
        }
        public ActionResult Staffs()
        {
            return View();
        }
        [HttpPost]// Post Staff

        //HTTP POST
        public ActionResult Staffs(StaffHos staffHos)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api/");
                var postTask = client.PostAsJsonAsync("Staffs", staffHos);
                postTask.Wait();
                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Staffs");
                }
            }
            ModelState.AddModelError(string.Empty, "Server Error.");

            return View(staffHos);
        }
        // GET show all Staffs
        public ActionResult ShowStaff()
        {
            IEnumerable<StaffHos> staff = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:50229/api");
                //HTTP GET
                var responseTask = client.GetAsync("Staff");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<StaffHos>>();
                    readTask.Wait();

                    staff = readTask.Result;
                }
                else 
                {
                    
                    staff = Enumerable.Empty<StaffHos>();

                    ModelState.AddModelError(string.Empty, "Server error. ");
                }
            }
            return View(staff);
        }
    }
}


